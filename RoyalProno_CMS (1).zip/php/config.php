<?php
// Configuration file
$db_host = 'localhost';
$db_user = 'root';
$db_password = '';
$db_name = 'royalprono';

$conn = new mysqli($db_host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

define('API_URL', 'https://api.football-data.org/v4/matches');
define('API_KEY', 'YOUR_API_KEY_HERE');
?>
