<?php
// Main page displaying live odds and analyses
include('php/config.php');
include('php/functions.php');
check_login();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>RoyalProno - Dashboard</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>Welcome to RoyalProno</h1>
        <p>Your trusted football betting analytics platform.</p>
    </header>
    <section>
        <div id="live_odds">
            <h2>Live Odds</h2>
            <div id="odds_container">Loading odds...</div>
        </div>
        <div id="analysis">
            <h2>Today's Analyses</h2>
            <div id="analysis_container">Loading analyses...</div>
        </div>
    </section>
    <script src="js/main.js"></script>
</body>
</html>
